package com.cg.university.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.university.exception.UniversityException;

public class DbUtil {
	public static Connection getConnection() throws UniversityException{
		InitialContext inicontext=null;
		try{
			inicontext=new InitialContext();
			DataSource datas=(DataSource) inicontext.lookup("java:/OracleDS");
			return datas.getConnection();
		}
		catch(NamingException e){
			throw new UniversityException(e.getMessage());
		}
			catch(SQLException e){
				throw new UniversityException(e.getMessage());
			}
		}

}
