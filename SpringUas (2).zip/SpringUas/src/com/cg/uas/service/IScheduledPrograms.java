package com.cg.uas.service;

import java.util.List;
import com.cg.uas.bean.ProgramsScheduledBean;

public interface IScheduledPrograms {

	public boolean addScheduledPrograms(ProgramsScheduledBean programs);

	public List<ProgramsScheduledBean> viewAllScheduledPrograms();

	public ProgramsScheduledBean viewScheduledProgram(int id);


}
