package com.cg.university.dao;


import com.cg.university.dto.ApplicationDto;
import com.cg.university.exception.UniversityException;



public interface ApplicationDAO {

		public ApplicationDto viewStatusById(int appid) throws UniversityException;
}
