package com.cg.university.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.university.dto.ApplicationDto;

import com.cg.university.dto.UserLogin;
import com.cg.university.exception.UniversityException;
import com.cg.university.util.DbUtil;

public class MacDAOImpl implements MacDAO {
Connection con=null;
PreparedStatement pst=null;
Statement st=null;
ResultSet rs=null;
	

	@Override
	public List<ApplicationDto> viewApplicant()
			throws UniversityException {
		List<ApplicationDto> applist=new ArrayList<ApplicationDto>();
		 con=DbUtil.getConnection();
		 try {
			 
			pst=con.prepareStatement("SELECT * FROM Application");
			rs=pst.executeQuery();
			while(rs.next()){
				ApplicationDto app=new ApplicationDto();
				app.setApplicationId(rs.getString(1));
				app.setFullName(rs.getString(2));
				app.setDateOfBirth(rs.getDate(3).toLocalDate());
				app.setHighestQualification(rs.getString(4));
				app.setMarksObtained(rs.getInt(5));
				app.setGoals(rs.getString(6));
				app.setEmailID(rs.getString(7));
				app.setScheduledProgramID(rs.getString("Scheduled_program_id"));
				app.setStatus(rs.getString("status"));
				applist.add(app);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		 
		return applist;
	}

	
	@Override
	public int interview(String appId,LocalDate date1)
			throws UniversityException {
		int dataadded=0;
		
		try {
			pst=con.prepareStatement("update application set  status=?,Date_Of_Interview=? where application_id=?");
			pst.setString(1,"accepted");
			pst.setDate(2,Date.valueOf(date1));
			pst.setString(3,appId.trim());
			dataadded=pst.executeUpdate();
			System.out.println(dataadded);
		} 
		catch (SQLException e) {
				e.printStackTrace();
		}
		
		return dataadded;
		
	}

	

	@Override
	public int reject(String appId) throws UniversityException {
		
		int dataadded=0;
		
		try {
			pst=con.prepareStatement("update application set  status=? where application_id=?");
			pst.setString(1,"rejected");
			pst.setString(2,appId.trim());
			dataadded=pst.executeUpdate();
			
		} 
		catch (SQLException e) {
				e.printStackTrace();
		}
		
		return dataadded;
	}

	@Override
	public boolean isvalid(UserLogin login) throws UniversityException {
		con=DbUtil.getConnection();
		
		String qry="select * from users where login_id=? and password=?";
			boolean isValid=false;
		try {
			pst=con.prepareStatement(qry);
			pst.setString(1, login.getUserName());
			pst.setString(2, login.getPassword());
			rs=pst.executeQuery();
			while(rs.next()){
			if(login.getUserName().equals(rs.getString("login_id")) && login.getPassword().equals(rs.getString("password")))
			{
				isValid=true;
			}
			else
			{
				isValid=false;
			}
			}
			
		} catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		
		
		
		return isValid;
	}


	@Override
	public int interviewresult(String id, String status) {
int dataadded=0;
		
		try {
			pst=con.prepareStatement("update application set  status=? where application_id=?");
			pst.setString(1,status);
			pst.setString(2,id.trim());
			dataadded=pst.executeUpdate();
			
		} 
		catch (SQLException e) {
				e.printStackTrace();
		}
		
		return dataadded;
	}
	
}
