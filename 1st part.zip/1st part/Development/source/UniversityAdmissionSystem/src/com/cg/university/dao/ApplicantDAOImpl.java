package com.cg.university.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;




import org.apache.log4j.Logger;

import com.cg.university.dto.ApplicationDto;
import com.cg.university.exception.UniversityException;
import com.cg.university.util.DbUtil;

public class ApplicantDAOImpl implements ApplicantDAO{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	

	@Override
	public int  addApplicant(ApplicationDto applicant)
			throws UniversityException {
		String id="Select application_id.nextval from dual";
		String insertQry="insert into application values(?,?,?,?,?,?,?,?,DEFAULT,null)";
		con=DbUtil.getConnection();
		
		int apid;
		try {
			st=con.createStatement();
			rs=st.executeQuery(id);
			rs.next();			
			apid=rs.getInt(1);
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,apid);
			pst.setString(2, applicant.getFullName());
			pst.setDate(3, Date.valueOf(applicant.getDateOfBirth()));
			pst.setString(4, applicant.getHighestQualification());
			pst.setInt(5, applicant.getMarksObtained());
			pst.setString(6, applicant.getGoals());
			pst.setString(7, applicant.getEmailID());
			pst.setString(8,applicant.getScheduledProgramID());
			Logger logger=Logger.getLogger(ApplicantDAO.class); //gets the logger file from log4j.properties
			logger.info("Row updated"); // when the values are entered it will print as row updated
			pst.executeUpdate();
						
		} catch (SQLException e) {
			
			throw new UniversityException(e.getMessage());
			
		}
		return apid;
		
	}

	
	

}
