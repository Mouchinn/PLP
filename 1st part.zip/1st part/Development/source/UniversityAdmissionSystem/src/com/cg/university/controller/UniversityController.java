package com.cg.university.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.cg.university.dto.ApplicationDto;
import com.cg.university.dto.ProgramsOfferedDto;
import com.cg.university.dto.UserLogin;
import com.cg.university.exception.UniversityException;
import com.cg.university.service.ApplicantService;
import com.cg.university.service.ApplicantServiceImpl;
import com.cg.university.service.ApplicationService;
import com.cg.university.service.ApplicationServiceImpl;
import com.cg.university.service.MacService;
import com.cg.university.service.MacServiceImpl;
import com.cg.university.service.ProgramsOfferedService;
import com.cg.university.service.ProgramsOfferedServiceImpl;
import com.cg.university.service.ScheduledProgramsService;
import com.cg.university.service.ScheduledProgramsServiceImpl;

@WebServlet("*.do")
public class UniversityController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ProgramsOfferedService service=new ProgramsOfferedServiceImpl();
	ScheduledProgramsService service1=new ScheduledProgramsServiceImpl();
	ApplicantService appservice=new ApplicantServiceImpl();
	ApplicationService apllservice=new ApplicationServiceImpl();
	MacService macservice=new MacServiceImpl();
	
    public UniversityController() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String urlPattern=request.getServletPath();
		RequestDispatcher dispatcher=null;
		ApplicationDto appdto=new ApplicationDto();
		
		System.out.println(urlPattern);
		
		switch(urlPattern){
		case"/Home.do":
			
			response.sendRedirect("Home.jsp");
		
			break;
			
			
		case "/Login.do":
			HttpSession session=null;
			String unm=request.getParameter("Username");
			String pwd=request.getParameter("password");
			UserLogin login=new UserLogin();
			login.setUserName(unm);
			login.setPassword(pwd);
			try {
				if(macservice.isvalid(login))
				{
					session=request.getSession();
					session.setAttribute("Username", unm);
					response.sendRedirect("machomepage.jsp");
					dispatcher.forward(request, response);
				}
				else
				{
					response.sendRedirect("LoginError.jsp");
					dispatcher.forward(request,response);
				}
			} catch (UniversityException e2) {
				dispatcher=request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e2);
				dispatcher.forward(request, response);
			}
			break;
					
		case "/Programs_offered.do":
			try{
				
				List<ProgramsOfferedDto> programs_offered=service.viewAllProgramsOffered();
				request.setAttribute("program_offered", programs_offered);
				dispatcher=request.getRequestDispatcher("programsoffered.jsp");
				dispatcher.forward(request, response);
			}
			catch(UniversityException e){
				dispatcher=request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
			
			
		case "/registration.do":
			String y=request.getParameter("id");
			request.getSession().setAttribute("programname", y);
			String x;
			
			try {
				
				x = service1.getProgramId(y);
				
				request.getSession().setAttribute("programID", x);
			} catch (UniversityException e1) {
				e1.printStackTrace();
			}
				
			
			
			dispatcher=request.getRequestDispatcher("Registration.jsp");
			dispatcher.forward(request, response);
			break;
			
			
		case "/Success.do":
			try{
			int AppId=0;
			String AppIDString=null;
			
			
			appdto.setFullName(request.getParameter("fullName"));
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("MM-dd-yyyy");
			String date=request.getParameter("dateOfBirth");
			LocalDate d=LocalDate.parse(date, dtf);
			appdto.setDateOfBirth(d);
			appdto.setHighestQualification(request.getParameter("highestQualification"));
			appdto.setMarksObtained(Integer.parseInt(request.getParameter("marksObtained")));
			appdto.setGoals(request.getParameter("goals"));
			appdto.setEmailID(request.getParameter("emailID"));
			appdto.setScheduledProgramID((String) request.getSession().getAttribute("programID"));
			
			AppId=appservice.addApplicant(appdto);
			AppIDString=String.valueOf(AppId);
			appdto.setApplicationId(AppIDString);
			request.setAttribute("appid", appdto);
			dispatcher=request.getRequestDispatcher("registrationsuccess.jsp");
			dispatcher.forward(request, response);
			}
			catch(UniversityException e){
				dispatcher=request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			
		break;
		
		
					
	case "/viewapplicants.do":
			List<ApplicationDto> applicants;
			try {
				applicants = macservice.viewApplicant();
				request.getSession().setAttribute("applicants", applicants);
				System.out.println("view.do");
			} catch (UniversityException e1) {
				
			}
		
		dispatcher=request.getRequestDispatcher("applicant.jsp");
		dispatcher.forward(request, response);
		
		break;
		
		
	case "/logout.do":	
		   response.setContentType("text/html");  
           session=request.getSession();  
           session.invalidate();  
           dispatcher=request.getRequestDispatcher("Logout.jsp");
           dispatcher.forward(request, response);  
             
           
		break;
		
		
	case "/Accept.do":
		System.out.println("Accept");
		request.setAttribute("applicationId",request.getParameter("id"));
		dispatcher=request.getRequestDispatcher("Interview.jsp");
		dispatcher.forward(request, response);
		break;
		
		
	case "/Set.do":
			
			
		DateTimeFormatter dtf=DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String date = request.getParameter("interviewdate");
		LocalDate d=LocalDate.parse(date, dtf);
		
		
		int updated;
		
			try { 
				
				
				String str = request.getParameter("appId");
				updated=macservice.interview(str, d);
							 
				 if(updated==1){
						request.setAttribute("Interviewdate", d);
						request.setAttribute("ApplicationId", request.getParameter("appId")); 
						dispatcher=request.getRequestDispatcher("AcceptSuccess.jsp");
						dispatcher.forward(request, response);
					}
					else{
						dispatcher=request.getRequestDispatcher("error.jsp");
						dispatcher.forward(request, response);	
					}
					
			} catch (NumberFormatException | UniversityException e1) {
				
				e1.getMessage();
			}
			
		break;
		
		
	case "/status.do":	
		dispatcher=request.getRequestDispatcher("status.jsp");
		dispatcher.forward(request, response);
		break;
	case "/checkstatus.do":
		String requestid=request.getParameter("registerId");
		
			try {
			
				appdto=apllservice.viewStatusById(Integer.parseInt(requestid));
				request.setAttribute("statusreport",appdto.getStatus());
				request.setAttribute("interviewdate", appdto.getDateOfInterview().toString());
				System.out.println(appdto.getDateOfInterview());
				dispatcher=request.getRequestDispatcher("statusreport.jsp");
				dispatcher.forward(request, response);
			
				
			} catch (NumberFormatException e) {
				
				e.printStackTrace();
			} catch (UniversityException e) {
				e.printStackTrace();
			}
		
			break;
			
	case "/machome.do":
		dispatcher=request.getRequestDispatcher("machomepage.jsp");
		dispatcher.forward(request, response);
		break;
	case "/Reject.do":
		int update=0;
		request.setAttribute("applicationId",request.getParameter("id"));
			try {
				update=macservice.reject(request.getParameter("id"));
				if(update==1){
				dispatcher=request.getRequestDispatcher("reject.jsp");
				dispatcher.forward(request, response);
				}
			} catch (UniversityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		break;
		
		
		/**********************************************************/
	case "/InterviewStatusUpdate.do":
		dispatcher=request.getRequestDispatcher("Interviewresult.jsp");
		dispatcher.forward(request, response);
		break;
	case "/Interviewresult.do":
		int resultupdated=0;
		String id=request.getParameter("registerId");
		String status=request.getParameter("status");
		System.out.println(status);
			resultupdated=macservice.interviewresult(id,status);
			if(resultupdated==1){
				dispatcher=request.getRequestDispatcher("machomepage.jsp");
				dispatcher.forward(request, response);
			}
		break;
}	
		
	}
		

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
