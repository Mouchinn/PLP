package com.cg.university.dto;

import java.sql.Date;

public class ProgramsScheduledDto {
	private String programId;
	private String programName;
	private String location;
	private Date startDate;
	private Date endDate;
	private String sessionPerWeek;
	public String getProgramId() {
		return programId;
	}
	public String setProgramId(String programId) {
		return this.programId=programId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getSessionPerWeek() {
		return sessionPerWeek;
	}
	public void setSessionPerWeek(String sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}
	@Override
	public String toString() {
		return "ProgramsScheduledDto [programId=" + programId
				+ ", programName=" + programName + ", location=" + location
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", sessionPerWeek=" + sessionPerWeek + "]";
	}
	
	
}
