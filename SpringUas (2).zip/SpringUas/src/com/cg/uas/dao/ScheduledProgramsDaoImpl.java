package com.cg.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.uas.bean.ProgramsScheduledBean;

@Repository
@Transactional
public class ScheduledProgramsDaoImpl implements IScheduledProgramsDao {

	@PersistenceContext
	EntityManager entitymanager;
	

	//------------------------ University Admission System --------------------------//
		/****************************************************************************
		 - Function Name	:	addScheduledPrograms
		 - Input Parameters	:	programs
		 - Return Type		:	boolean
		 - Throws		    :  	UASException
		 - Author			:	Group 4
		 - Description		:	adds the program to scheduled program
		 ******************************************************************************/
	@Override
	public boolean addScheduledPrograms(ProgramsScheduledBean programs) {
		entitymanager.persist(programs);
		return (true);

	}

	//------------------------ University Admission System --------------------------//
		/****************************************************************************
		 - Function Name	:	viewAllScheduledPrograms
		 - Return Type		:	list
		 - Throws		    :  	UASException
		 - Author			:	Group 4
		 - Description		:	retrieves all the scheduled programs and returns the list
		 ******************************************************************************/

	@Override
	public List<ProgramsScheduledBean> viewAllScheduledPrograms() {
		TypedQuery<ProgramsScheduledBean> query = entitymanager.createQuery(
				"from ProgramsScheduledBean ", ProgramsScheduledBean.class);
		List<ProgramsScheduledBean> list = query.getResultList();
		return list;
	}

	//------------------------ University Admission System --------------------------//
		/****************************************************************************
		 - Function Name	:	viewScheduledProgram
		 - Input Parameters	:	id
		 - Return Type		:	ProgramsScheduledBean
		 - Throws		    :  	UASException
		 - Author			:	Group 4
		 - Description		:	retrieves all the scheduled program details 
		 ******************************************************************************/
	@Override
	public ProgramsScheduledBean viewScheduledProgram(int id) {
		return entitymanager.find(ProgramsScheduledBean.class, id);
	}

}
