package com.cg.university.service;



import com.cg.university.dao.ScheduledProgramsDAO;
import com.cg.university.dao.ScheduledProgramsDAOImpl;

import com.cg.university.exception.UniversityException;

public class ScheduledProgramsServiceImpl implements ScheduledProgramsService {
	ScheduledProgramsDAO dao=new ScheduledProgramsDAOImpl();



	@Override
	public String getProgramId(String Programname) throws UniversityException {
		
		return dao.getProgramId(Programname);
	}

}
