package com.cg.university.service;


import com.cg.university.dao.ApplicationDAO;
import com.cg.university.dao.ApplicationDAOImpl;
import com.cg.university.dto.ApplicationDto;
import com.cg.university.exception.UniversityException;

public class ApplicationServiceImpl implements ApplicationService {
	ApplicationDAO appdao=new ApplicationDAOImpl();
	

	@Override
	public ApplicationDto viewStatusById(int appid) throws UniversityException {
		
		try {
			return appdao.viewStatusById(appid);
		} catch (UniversityException e) {
			throw new UniversityException();
		}
	}

}
