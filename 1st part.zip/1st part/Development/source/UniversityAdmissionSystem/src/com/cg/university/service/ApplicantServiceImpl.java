package com.cg.university.service;



import com.cg.university.dao.ApplicantDAO;
import com.cg.university.dao.ApplicantDAOImpl;
import com.cg.university.dto.ApplicationDto;

import com.cg.university.exception.UniversityException;

public class ApplicantServiceImpl implements ApplicantService {
	ApplicantDAO appdao=new ApplicantDAOImpl();

	
	

	@Override
	public int addApplicant(ApplicationDto applicant)
			throws UniversityException {
		
		return appdao.addApplicant(applicant);
	}

	

	
}
