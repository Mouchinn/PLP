package com.cg.university.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.university.dao.MacDAO;
import com.cg.university.dao.MacDAOImpl;
import com.cg.university.dto.ApplicationDto;
import com.cg.university.dto.UserLogin;
import com.cg.university.exception.UniversityException;

public class MacDaoTest {
MacDAO macdao;
@Before
public void init(){
	macdao=new MacDAOImpl();
}
	/*@Test
	public void testViewApplicant() {
		try {
			assertNotNull(macdao.viewApplicant());
			assertEquals(, actual);
		} catch (UniversityException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testInterview() {
		fail("Not yet implemented");
	}*/

	/*@Test*/
	/*public void testReject() {
		try {
					
		} catch (UniversityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
*/
	@Test
	public void testIsvalid() {
		UserLogin log=new UserLogin();
		log.setUserName("mac");
		log.setPassword("mac");
		
		
		
		try {
			assertTrue("test fails",macdao.isvalid(log));
		} catch (UniversityException e) {
			e.printStackTrace();
		}
	}

	/*@Test
	public void testInterviewresult() {
		fail("Not yet implemented");
	}

}*/
}
