package com.cg.uas.dao;

import java.util.List;

import com.cg.uas.bean.ProgramsScheduledBean;

public interface IScheduledProgramsDao {

	public boolean addScheduledPrograms(ProgramsScheduledBean programs);

	public List<ProgramsScheduledBean> viewAllScheduledPrograms();

	public ProgramsScheduledBean viewScheduledProgram(int id);
}
