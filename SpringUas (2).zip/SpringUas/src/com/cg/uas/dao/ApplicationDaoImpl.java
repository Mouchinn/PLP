package com.cg.uas.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.uas.bean.ApplicationBean;

@Repository
@Transactional
public class ApplicationDaoImpl implements IApplicationDao {

	@PersistenceContext
	private EntityManager entitymanager;

	//------------------------ University Admission System --------------------------//
		/************************************************************************************
	 	- Function Name	    :	addApplicant
	 	- Input Parameters  :   applicant
	 	- Return Type		:	ApplicationBean
	 	- Throws		    :  	UASException
	 	- Author			:	Group 4
	 	- Description		:	adds the applicant details
		**************************************************************************************/
	@Override
	public ApplicationBean addApplicant(ApplicationBean applicant) {
		applicant.setStatus("applied");
		entitymanager.persist(applicant);
		entitymanager.flush();
		return applicant;
	}
	
	//------------------------ University Admission System --------------------------//
		/************************************************************************************
		 - Function Name	:	viewStatusById
		 - Input Parameters :   appid
		 - Return Type		:	ApplicationBean
		 - Throws		    :  	UASException
		 - Author			:	Group 4
		 - Description		:	view the status of the applicant by id
		 **************************************************************************************/
	@Override
	public ApplicationBean viewStatusById(int appid) {
		ApplicationBean app = entitymanager.find(ApplicationBean.class, appid);
		return app;
	}
}
