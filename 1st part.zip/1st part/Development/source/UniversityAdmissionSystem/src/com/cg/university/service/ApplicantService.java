package com.cg.university.service;



import com.cg.university.dto.ApplicationDto;

import com.cg.university.exception.UniversityException;

public interface ApplicantService {
	
	public int addApplicant(ApplicationDto applicant)
			throws UniversityException;



}
