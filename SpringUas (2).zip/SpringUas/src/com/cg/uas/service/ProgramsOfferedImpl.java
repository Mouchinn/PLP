package com.cg.uas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.bean.ProgramsOfferedBean;
import com.cg.uas.bean.UserBean;
import com.cg.uas.dao.IProgramsOfferedDao;
import com.cg.uas.exception.UASException;

@Service
public class ProgramsOfferedImpl implements IProgramsOffered {

	@Autowired
	IProgramsOfferedDao programDao;
	
	//------------------------ University Admission System --------------------------//
		/**************************************************************************************
			- Function Name	    :	addProgram
			- Input Parameters	:	program
			- Return Type		:	boolean
			- Throws			:  	UASException
			- Author			:	Group 4
			- Description		:   calls dao method addProgram()
		*************************************************************************************/
	@Override
	public boolean addProgram(ProgramsOfferedBean program) {
		boolean flag = programDao.addProgram(program);
		return flag;
	}
	
	//------------------------ University Admission System --------------------------//
		/**************************************************************************************
			- Function Name	    :	viewAllProgramsOffered
			- Return Type		:	list
			- Throws			:  	UASException
			- Author			:	Group 4
			- Description		:   calls dao method viewAllProgramsOffered()
	    *************************************************************************************/
	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() {
		return programDao.viewAllProgramsOffered();
	}
	
	//------------------------ University Admission System --------------------------//
		/**************************************************************************************
			- Function Name	    :	checkuser
			- Return Type		:	UserBean
			- Throws			:  	UASException
			- Author			:	Group 4
			- Description		:   calls dao method checkuser()
		 *************************************************************************************/
	@Override
	public UserBean checkUser(String id, String password) throws UASException {
		return programDao.checkUser(id, password);
	}
	

}
