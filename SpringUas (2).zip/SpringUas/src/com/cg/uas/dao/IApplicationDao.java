package com.cg.uas.dao;

import com.cg.uas.bean.ApplicationBean;

public interface IApplicationDao {

	public ApplicationBean addApplicant(ApplicationBean applicant);

	public ApplicationBean viewStatusById(int appid);
}
