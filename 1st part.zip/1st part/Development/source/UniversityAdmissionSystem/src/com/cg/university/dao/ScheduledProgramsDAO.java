package com.cg.university.dao;


import com.cg.university.exception.UniversityException;


public interface ScheduledProgramsDAO {

	
	public String getProgramId(String programname) throws UniversityException;

}
