package com.cg.university.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.university.exception.UniversityException;
import com.cg.university.util.DbUtil;

public class ScheduledProgramsDAOImpl implements ScheduledProgramsDAO {
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	

	@Override
	public String getProgramId(String programname) throws UniversityException {
		Connection con=null;
		PreparedStatement stat=null;
		ResultSet rs=null;
		con=DbUtil.getConnection();
		String x=null;
		try{
			
			stat=con.prepareStatement("SELECT Scheduled_program_id from Program_Scheduled where ProgramName=?");
			stat.setString(1,programname);
			rs=stat.executeQuery();
			if(rs.next()){
				 x=rs.getString(1);
				 System.out.println(x);
			}
			return x;
			
		}catch(SQLException e){
			throw new UniversityException(e.getMessage());	
			}
			finally{
			try{
				con.close();
				stat.close();
				rs.close();
			}catch(SQLException e){
				throw new UniversityException(e.getMessage());
			}
		}

	}
		
	}


