package com.cg.uas.service;

import java.util.List;

import com.cg.uas.bean.ProgramsOfferedBean;
import com.cg.uas.bean.UserBean;
import com.cg.uas.exception.UASException;

public interface IProgramsOffered {

	public boolean addProgram(ProgramsOfferedBean program);

	public List<ProgramsOfferedBean> viewAllProgramsOffered();

	public UserBean checkUser(String id, String password) throws UASException;
}
