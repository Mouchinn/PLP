package com.cg.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.uas.bean.ProgramsOfferedBean;
import com.cg.uas.bean.UserBean;
import com.cg.uas.exception.UASException;

@Repository
@Transactional
public class ProgramsOfferedDaoImpl implements IProgramsOfferedDao {

	@PersistenceContext
	EntityManager entitymanager;
	
	//------------------------ University Admission System --------------------------//
		/****************************************************************************
		 - Function Name	:	addProgram
		 - Input Parameters	:	program
		 - Return Type		:	boolean
		 - Throws		    :  	UASException
		 - Author			:	Group 4
		 - Description		:	adds the program to offered programs
		 ******************************************************************************/
	@Override
	public boolean addProgram(ProgramsOfferedBean program) {
		entitymanager.persist(program);
		return (true);
	}

	//------------------------ University Admission System --------------------------//
		/****************************************************************************
	 	- Function Name	    :	viewAllProgramsOffered
	 	- Return Type		:	list
	 	- Throws		    :  	UASException
	 	- Author			:	Group 4
	 	- Description		:	retrieves all the offered programs
		******************************************************************************/
	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() {

		TypedQuery<ProgramsOfferedBean> query = entitymanager.createQuery(
				"from ProgramsOfferedBean ", ProgramsOfferedBean.class);
		List<ProgramsOfferedBean> list = query.getResultList();
		return list;
	}

	//------------------------ University Admission System --------------------------//
		/****************************************************************************
	 	- Function Name	    :	checkuser
	 	- Return Type		:	id,password
	 	- Throws		    :  	UASException
	 	- Author			:	Group 4
	 	- Description		:	checks the user is valid/invalid
		 ******************************************************************************/
	
	@Override
	public UserBean checkUser(String id, String password) throws UASException {
		TypedQuery<UserBean> query = entitymanager
				.createQuery("from UserBean where userName=? and password=?",
						UserBean.class);
		query.setParameter(1, id);
		query.setParameter(2, password);
		try {
			UserBean user = query.getSingleResult();
			return user;
		} catch (Exception e) {
		}
		return null;

	}
	
}
