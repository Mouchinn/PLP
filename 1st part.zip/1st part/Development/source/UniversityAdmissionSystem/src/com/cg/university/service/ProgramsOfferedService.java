package com.cg.university.service;

import java.util.List;

import com.cg.university.dto.ProgramsOfferedDto;

import com.cg.university.exception.UniversityException;

public interface ProgramsOfferedService {

	
	public List<ProgramsOfferedDto> viewAllProgramsOffered() throws UniversityException;

	

}
