package com.cg.university.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.university.dto.ApplicationDto;
import com.cg.university.exception.UniversityException;
import com.cg.university.util.DbUtil;

public class ApplicationDAOImpl implements ApplicationDAO{
	Connection con=null;
	Statement stat=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	

	@Override
	public ApplicationDto viewStatusById(int appid)  throws UniversityException {
		con=DbUtil.getConnection();
		 ApplicationDto app=new ApplicationDto();
		 String status=null;
		try {
			pst=con.prepareStatement("select status,date_of_interview from application where application_id=?");
			pst.setInt(1,appid);
			rs=pst.executeQuery();
			
			while(rs.next()){
				  app.setStatus(rs.getString("status"));
				  app.setDateOfInterview(rs.getDate("date_of_interview").toLocalDate());
	
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return app;
	}

}
