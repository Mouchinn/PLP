package com.cg.uas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.uas.bean.ProgramsScheduledBean;
import com.cg.uas.dao.IScheduledProgramsDao;

@Service
public class ScheduledProgramsImpl implements IScheduledPrograms {

	@Autowired
	IScheduledProgramsDao programDao;
	
	//------------------------ University Admission System --------------------------//
		/**************************************************************************************
		 - Function Name	:	addScheduledPrograms
		 - Input Parameters	:	programs
		 - Return Type		:	boolean
		 - Throws			:  	UASException
		 - Author			:	Group 4
		 - Description		:   calls dao method addScheduledPrograms()
		 *************************************************************************************/
	
	@Override
	public boolean addScheduledPrograms(ProgramsScheduledBean programs) {
		boolean flag = programDao.addScheduledPrograms(programs);
		return flag;
	}
	
	//------------------------ University Admission System --------------------------//
		/**************************************************************************************
		  - Function Name	:	viewAllScheduledPrograms
		  - Return Type		:	list
	   	  - Throws			:  	UASException
		  - Author			:	Group 4
		  - Description		:   calls dao method viewScheduledPrograms()
		 *************************************************************************************/
	
	@Override
	public List<ProgramsScheduledBean> viewAllScheduledPrograms() {
		return programDao.viewAllScheduledPrograms();
	}
	
	//------------------------ University Admission System --------------------------//
		/**************************************************************************************
			- Function Name	    :	viewAllScheduledProgram
			- Input Parameter   :   id
			- Return Type		:	ProgramsScheduledBean
		   	- Throws			:  	UASException
			- Author			:	Group 4
			- Description		:   calls dao method viewScheduledProgram()
		*************************************************************************************/
	@Override
	public ProgramsScheduledBean viewScheduledProgram(int id) {
		return programDao.viewScheduledProgram(id);
	}
	
}
