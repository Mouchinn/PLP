package com.cg.university.service;

import com.cg.university.dto.ApplicationDto;
import com.cg.university.exception.UniversityException;



public interface ApplicationService {


	public ApplicationDto viewStatusById(int appid) throws UniversityException;
}
