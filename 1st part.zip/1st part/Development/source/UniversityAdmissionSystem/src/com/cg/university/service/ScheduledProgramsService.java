package com.cg.university.service;


import com.cg.university.exception.UniversityException;

public interface ScheduledProgramsService {

	
	public String getProgramId(String Programname) throws UniversityException;

}
