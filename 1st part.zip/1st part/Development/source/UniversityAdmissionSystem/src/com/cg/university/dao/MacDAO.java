package com.cg.university.dao;


import java.time.LocalDate;
import java.util.List;

import com.cg.university.dto.ApplicationDto;

import com.cg.university.dto.UserLogin;
import com.cg.university.exception.UniversityException;



public interface MacDAO {
	
			
	public boolean isvalid(UserLogin login) throws UniversityException;

	public List<ApplicationDto> viewApplicant()
			throws UniversityException;

	

	public int interview(String appId,LocalDate date) throws UniversityException;


	

	public int reject(String appId) throws UniversityException;

	public int interviewresult(String id, String status);


}
