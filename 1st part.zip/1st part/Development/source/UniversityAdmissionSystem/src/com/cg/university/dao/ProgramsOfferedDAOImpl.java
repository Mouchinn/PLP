package com.cg.university.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.university.dto.ProgramsOfferedDto;

import com.cg.university.exception.UniversityException;
import com.cg.university.util.DbUtil;

public class ProgramsOfferedDAOImpl implements ProgramsOfferedDAO {

	
	@Override
	public List<ProgramsOfferedDto> viewAllProgramsOffered() throws UniversityException {
		List<ProgramsOfferedDto> programs_offered=new ArrayList<ProgramsOfferedDto>();
		Connection con=null;
		Statement stat=null;
		ResultSet rs=null;
		con=DbUtil.getConnection();
		try{
			stat=con.createStatement();
			rs=stat.executeQuery("select * from program_offered");
			while(rs.next()){
				ProgramsOfferedDto  emp=new ProgramsOfferedDto();
				emp.setProgramName(rs.getString(1));
				emp.setDescription(rs.getString(2));
				emp.setApplicantEligibility(rs.getString(3));
				emp.setDuration(rs.getString(4));
				emp.setDegreeCertificate(rs.getString(5));
				programs_offered.add(emp);
			}
			return programs_offered;
			
		}
		catch(SQLException e){
			throw new UniversityException(e.getMessage());	
			}
			finally{
						try{
				con.close();
				stat.close();
				rs.close();
			}catch(SQLException e){
				throw new UniversityException(e.getMessage());
			}
		}

	}
	

}
