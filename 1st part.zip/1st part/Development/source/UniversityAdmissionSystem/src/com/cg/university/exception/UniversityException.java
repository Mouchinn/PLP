package com.cg.university.exception;

public class UniversityException extends Exception {

	public UniversityException() {
		super();
		
	}

	public UniversityException(String message) {
		super(message);
		
	}

}
