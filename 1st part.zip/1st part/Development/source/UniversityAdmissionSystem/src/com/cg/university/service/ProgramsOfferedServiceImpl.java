package com.cg.university.service;

import java.util.List;

import com.cg.university.dao.ProgramsOfferedDAO;
import com.cg.university.dao.ProgramsOfferedDAOImpl;
import com.cg.university.dto.ProgramsOfferedDto;

import com.cg.university.exception.UniversityException;

public class ProgramsOfferedServiceImpl implements ProgramsOfferedService {
	ProgramsOfferedDAO programsoffereddao=new ProgramsOfferedDAOImpl();

	
	@Override
	public List<ProgramsOfferedDto> viewAllProgramsOffered() throws UniversityException {
		return programsoffereddao.viewAllProgramsOffered() ;
	}

	

}
