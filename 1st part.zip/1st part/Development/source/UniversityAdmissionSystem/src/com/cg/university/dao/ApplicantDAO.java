package com.cg.university.dao;


import com.cg.university.dto.ApplicationDto;

import com.cg.university.exception.UniversityException;


public interface ApplicantDAO {

	public  int addApplicant(ApplicationDto applicant)
			throws UniversityException;

	
	
	
}
