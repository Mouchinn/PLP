package com.cg.university.service;


import java.time.LocalDate;
import java.util.List;

import com.cg.university.dao.MacDAO;
import com.cg.university.dao.MacDAOImpl;
import com.cg.university.dto.ApplicationDto;

import com.cg.university.dto.UserLogin;
import com.cg.university.exception.UniversityException;

public class MacServiceImpl implements MacService {
	MacDAO dao=new MacDAOImpl();
	
	@Override
	public List<ApplicationDto> viewApplicant()
			throws UniversityException {
		
		return dao.viewApplicant();
	}

	

	@Override
	public int interview(String appId, LocalDate date)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.interview(appId, date);
	}

	

	@Override
	public int reject(String appId) throws UniversityException {
		// TODO Auto-generated method stub
		return dao.reject(appId);	}

	@Override
	public boolean isvalid(UserLogin login) throws UniversityException {
		// TODO Auto-generated method stub
		return dao.isvalid(login);
	}



	@Override
	public int interviewresult(String id, String status) {
		// TODO Auto-generated method stub
		return dao.interviewresult(id,status);
	}

}
