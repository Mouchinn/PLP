package com.cg.university.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.university.dao.ApplicantDAO;
import com.cg.university.dao.ApplicantDAOImpl;
import com.cg.university.dto.ApplicationDto;
import com.cg.university.exception.UniversityException;


public class ApplicantDaoTest {

	/*@Test
	public void testAddApplicant() {
		ApplicantDAO dao=new ApplicantDAOImpl();
        try{
		assertNotNull(dao.addApplicant(ApplicationDto.applicant));
        }
        catch(UniversityException e){
        	System.err.println("error mesaage");
        }
	}*/

}
